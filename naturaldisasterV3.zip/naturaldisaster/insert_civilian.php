<html>
<head>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>

<?php

include 'connect.php';

if(isset($_POST["submit"])) {

    $name = $_POST['name'];
    $last_name = $_POST['last_name'];
    $phone_number = $_POST['phone_number'];
    $username = $_POST['user_name']; // Διόρθωση: name attribute = "user_name"
    $password = $_POST['p']; // Διόρθωση: name attribute = "p"

    // Έλεγχος αν το username υπάρχει ήδη
    $checkUsername = "SELECT COUNT(*) as total FROM civilian WHERE username_civ = '$username'";
    $result = $conn->query($checkUsername);
    $row = $result->fetch_assoc();

    if ($row['total'] > 0) {
        // Το username υπάρχει ήδη
        echo "Username already exists. Please choose a different username.";
    } else {
        // Το username δεν υπάρχει, proceed με την εγγραφή
        $insert = "INSERT INTO civilian (username_civ, password_civ, phone_number, name, last_name) 
                   VALUES ('$username', '$password', '$phone_number', '$name', '$last_name')";

        if($conn->query($insert) === TRUE) {
            echo "You registered successfully!";
            echo "<a href='index.php'> Go Back to Login  </a>";
        } else {
            echo "Error: " . $conn->error;
        }
    }
}

?>

</body>
</html>
