<html>

<head>

    <link rel="stylesheet" href="mystyle.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

</head>

<body>

<div class="container">
    <form action = "insert_civilian.php" method = "post">
        <div class="form-group">
            <input type = "text" class="form-control" name = "name" placeholder="First Name">
        </div>
        <br>
        <div class="form-group">
            <input type = "text" class="form-control" name = "last_name" placeholder="Last Name">
        </div>
        <br>
        <div class="form-group">
            <input type = "text" class="form-control" name = "phone_number" placeholder="Phone Number">
        </div>
        <br>
        <div class="form-group">
            <input type = "text" class="form-control" name = "user_name" placeholder="Username">
        </div>
        <br>
        <div class="form-group">
            <input type = "password" class="form-control" name = "p" placeholder="Password">
        </div>
        <br>
        <div class="form-group">
            <input type = "submit" class="btn btn-primary" value = "Register" name="submit">
        </div>
    </form>
</div>
<br><br>

<a href = "index.php"> Return </a>

</body>

</html>