INSERT INTO admin VALUES
("giannis","1");

INSERT INTO rescuer VALUES
("giannis","2"),
("giannis","3"),
("giannis","4");

INSERT INTO civilian (username_civ, password_civ, phone_number, name,last_name)
VALUES 
('user1', 'pass1', '123-456-7890', 'John','Doe'),
('user2', 'pass2', '234-567-8901', 'Jane','Smith'),
('user3', 'pass3', '345-678-9012', 'Alice','Johnson'),
('user4', 'pass4', '456-789-0123', 'Bob','Brown'),
('user5', 'pass5', '567-890-1234', 'Carol','Davis');

INSERT INTO new_request (username, item_name, people_count, request_date, status_request, acceptance_date, completion_date) 
VALUES 
('user1', 'Chocolate', 5, '2023-07-01', 'PENDIND', NULL, NULL),
('user1', 'Bread', 10, '2023-07-05', 'ACCEPTED', '2023-07-06', NULL),
('user2', 'Fakes', 3, '2023-07-10', 'COMPLITED', '2023-07-11', '2023-07-15'),
('user2', 'Canned', 7, '2023-07-20', 'PENDIND', NULL, NULL),
('user2', 'Water', 2, '2023-07-25', 'ACCEPTED', '2023-07-26', NULL),
('user1', 'Fruits', 4, '2023-08-01', 'COMPLITED', '2023-08-02', '2023-08-10');

