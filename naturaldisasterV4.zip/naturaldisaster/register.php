<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="mystyle.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <?php
    include 'connect.php';

    if(isset($_POST["submit"])) {
        $name = $_POST['name'];
        $last_name = $_POST['last_name'];
        $phone_number = $_POST['phone_number'];
        $username = $_POST['user_name'];
        $password = $_POST['p'];

        // Έλεγχος αν το username υπάρχει ήδη
        $checkUsername = "SELECT COUNT(*) as total FROM civilian WHERE username_civ = '$username'";
        $result = $conn->query($checkUsername);
        $row = $result->fetch_assoc();

        if ($row['total'] > 0) {
            // Το username υπάρχει ήδη
            echo "<div class='alert alert-danger'>Username already exists. Please choose a different username.</div>";
        } else {
            // Το username δεν υπάρχει, proceed με την εγγραφή
            $insert = "INSERT INTO civilian (username_civ, password_civ, phone_number, name, last_name) 
                       VALUES ('$username', '$password', '$phone_number', '$name', '$last_name')";

            if($conn->query($insert) === TRUE) {
                echo "<div class='alert alert-success'>You registered successfully!</div>";
                echo "<a href='index.php' class='btn btn-primary'>Go Back to Login</a>";
            } else {
                echo "<div class='alert alert-danger'>Error: " . $conn->error . "</div>";
            }
        }
    }
    ?>

    <form action="register.php" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="name" placeholder="First Name" required>
        </div>
        <br>
        <div class="form-group">
            <input type="text" class="form-control" name="last_name" placeholder="Last Name" required>
        </div>
        <br>
        <div class="form-group">
            <input type="text" class="form-control" name="phone_number" placeholder="Phone Number" required>
        </div>
        <br>
        <div class="form-group">
            <input type="text" class="form-control" name="user_name" placeholder="Username" required>
        </div>
        <br>
        <div class="form-group">
            <input type="password" class="form-control" name="p" placeholder="Password" required>
        </div>
        <br>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Register" name="submit">
        </div>
    </form>
</div>
<br><br>

<a href="index.php">Return</a>

</body>
</html>
