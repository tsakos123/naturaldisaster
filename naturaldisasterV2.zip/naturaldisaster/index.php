<html>

<head>

    <link rel="stylesheet" href="mystyle.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">

</head>
<body>


<table border='1'>

    <tr>

        <td>
            <h2>  Civilian Login Area </h2>
            <form action = "validate_civilian.php" method = "post">
                <div class="form-group">
                    <input type = "text" class="form-control" name = "username" placeholder="username">
                </div>
                <br><br>
                <div class="form-group">
                    <input type = "password" class="form-control" name ="password" placeholder="password">
                </div>
                <br><br>
                <input type = "submit" value ="Login">
            </form>

        </td>

        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>

        <td>

            <h2>  Admin Login Area </h2>
            <form action = "validate_admin.php" method = "post">
                <div class="form-group">
                    <input type = "text" class="form-control" name = "username" placeholder="username">
                </div>
                <br><br>
                <div class="form-group">
                    <input type = "password" class="form-control" name ="password" placeholder="password">
                </div>
                <br><br>
                <input type = "submit" value ="Login">
            </form>




        </td>

        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
        <td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>


        <td>
            <h2>  Rescuer Login Area </h2>
            <form action = "validate_rescuer.php" method = "post">
                <div class="form-group">
                    <input type = "text" class="form-control" name = "username" placeholder="username">
                </div>
                <br><br>
                <div class="form-group">
                    <input type = "password" class="form-control" name ="password" placeholder="password">
                </div>
                <br><br>
                <input type = "submit" value ="Login">
            </form>

        </td>


    </tr>

    <tr>
        <td colspan='80' align = 'center'>  <a href = "register.php"> Registration  </a>  </td>

    </tr>

</table>


</body>


</html>