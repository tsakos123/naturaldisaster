<html>
<head>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>

<?php

include 'connect.php';
include 'register.php';


if(isset($_POST["Register"])) {

    $name = $_POST['name'];
    $last_name = $_POST['last_name'];
    $phone_number = $_POST['phone_number'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $insert = "INSERT INTO new_civilian VALUES ('$name','$last_name','$phone_number','$username','$password')";

}
if($conn->query($insert)===TRUE)

{
    echo "You registered with success!";
    echo "<a href='index.php'> Go Back to Login  </a>";
}
else
{
    echo "wrong input.";
}
?>

</body>

</html>