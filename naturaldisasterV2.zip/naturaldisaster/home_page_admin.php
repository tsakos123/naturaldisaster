<?php

include 'check_session.php';

header("Location: menu_admin.html");



?>