<?php
include 'connect.php';

$sql = "SELECT id, name, category_id, quantity FROM items";
$result = $conn->query($sql);

$items = array();
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}

echo json_encode($items);

$conn->close();
?>
