<?php

include 'check_session.php';

header("Location: view_map_admin.php");



?>