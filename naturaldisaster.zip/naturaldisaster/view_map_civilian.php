<!DOCTYPE html>
<html lang="el">
<head>
    <meta charset="UTF-8">
    <title>Διαχείριση Αιτημάτων</title>
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/leaflet@1.3.3/dist/leaflet.css">
    <script src="https://unpkg.com/leaflet@1.3.3/dist/leaflet.js"></script>
    <style>
        #map {
            height: 750px;
        }
        .request-form, .request-list {
            margin: 20px;
        }
        .request-item {
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<div id="map"></div>

<div class="request-form">
    <h2>Δημιουργία Νέου Αιτήματος</h2>
    <label for="category_select">Κατηγορία:</label>
    <select id="category_select" onchange="populateItems()">
        <option value="">Επιλέξτε Κατηγορία</option>
    </select>
    <br>
    <label for="item_name">Είδος:</label>
    <select id="item_name">
        <option value="">Επιλέξτε Είδος</option>
    </select>
    <br>
    Πλήθος ατόμων: <input type="number" id="people_count">
    <br>
    <button onclick="createRequest()">Υποβολή</button>
</div>

<div class="request-list">
    <h2>Τα Αιτήματά Μου</h2>
    <ul id="request_list"></ul>
</div>

<script>
    // Initialize the map
    var map = L.map('map').setView([38.293166, 21.791718], 14);
    var base = L.marker([38.290182, 21.795689]).addTo(map);
    var rescuer = L.marker([38.309757, 21.785289]).addTo(map);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);

    var items = [];
    var categories = [];

    // Fetch data from JSON
    fetch('items_and_categories.json')
        .then(response => response.json())
        .then(data => {
            console.log('Data loaded:', data); // Debugging line
            items = data.items;
            categories = data.categories;
            populateCategories();
        })
        .catch(error => console.error('Error loading JSON:', error));

    function populateCategories() {
        var categorySelect = document.getElementById('category_select');
        categories.forEach(category => {
            var option = document.createElement('option');
            option.value = category.id;
            option.text = category.category_name || 'Χωρίς Όνομα'; // Default text if category name is empty
            categorySelect.add(option);
        });
    }

    function populateItems() {
        var categoryId = document.getElementById('category_select').value;
        var itemSelect = document.getElementById('item_name');
        itemSelect.innerHTML = '<option value="">Επιλέξτε Είδος</option>'; // Clear previous items

        if (categoryId) {
            items.forEach(item => {
                if (item.category === categoryId) {
                    var option = document.createElement('option');
                    option.value = item.name;
                    option.text = item.name || 'Χωρίς Όνομα'; // Default text if item name is empty
                    itemSelect.add(option);
                }
            });
        }
    }

    function createRequest() {
        var itemName = document.getElementById('item_name').value;
        var peopleCount = document.getElementById('people_count').value;
        if (itemName && peopleCount) {
            var requestList = document.getElementById('request_list');
            var li = document.createElement('li');
            li.classList.add('request-item');
            li.innerHTML = 'Είδος: ' + itemName + ', Πλήθος ατόμων: ' + peopleCount;
            requestList.appendChild(li);

            // Example of sending the request to the server
            // fetch('/submit_request', {
            //     method: 'POST',
            //     headers: {
            //         'Content-Type': 'application/json'
            //     },
            //     body: JSON.stringify({ itemName: itemName, peopleCount: peopleCount })
            // })
            // .then(response => response.json())
            // .then(data => console.log('Request submitted:', data))
            // .catch(error => console.error('Error submitting request:', error));
        } else {
            alert('Παρακαλώ συμπληρώστε όλα τα πεδία.');
        }
    }
</script>
</body>
</html>
