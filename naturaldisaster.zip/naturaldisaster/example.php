<?php
echo file_get_contents('items_and_categories.json');